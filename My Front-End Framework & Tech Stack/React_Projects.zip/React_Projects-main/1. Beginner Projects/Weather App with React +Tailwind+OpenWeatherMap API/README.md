# 🌦️ Weather App

A clean, simple React weather app that uses OpenWeatherMap and Iconify for beautiful icons.

## 🚀 Features

- Search for any city
- Get live temperature, humidity, and weather status
- Responsive UI
- Uses Iconify (Open Source) for weather icons

